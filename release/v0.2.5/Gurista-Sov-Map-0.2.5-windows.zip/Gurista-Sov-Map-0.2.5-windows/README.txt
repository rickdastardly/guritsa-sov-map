Gurista - Sov Map (Windows)
===========================

Run GuristaSovMap.exe. That's it: no install needed. Put the folder anywhere you like
(for example Documents or your desktop) and make a shortcut to GuristaSovMap.exe.

First run: Windows may say "Windows protected your PC" because the app is new and not
code-signed. Click "More info", then "Run anyway".

Needs Windows 10 or 11 (64-bit). Nothing else to install: no runtime DLLs. The map is drawn
by Microsoft Edge WebView2, which comes with Windows 11 and up-to-date Windows 10; if it's
missing, the app opens Microsoft's download page for it (the Setup installer installs it for you).

Updates: the app checks for new versions on its own and offers a one-click update.

Keys: F11 fullscreen, F5 reload, / search, Esc clear selection.
Intel channels: open "Comms" on the left, tick your intel channels. The app reads your
EVE chat logs (Documents\EVE\logs\Chatlogs) on your PC only.

Settings and cache live in %APPDATA%\Gurista\SovMap and %LOCALAPPDATA%\Gurista\SovMap.
To remove the app, delete this folder and those two folders.

Website: https://gurista.co.uk/sov-map/
Source:  https://github.com/rickdastardly/gurista-sov-map

EVE Online and the EVE logo are the registered trademarks of CCP hf. All rights reserved.
Used with permission. Not affiliated with CCP.
